from datetime import datetime
from sqlite3 import Timestamp
from xml.etree.ElementInclude import include
import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import pandas


# read gyroscope data over x, y, z
filepath = ['GyroscopeFrequency10.txt','GyroscopeFrequency20.txt','GyroscopeFrequency30.txt','GyroscopeFrequency40.txt','GyroscopeFrequency50.txt']
cnt = 0
for ls in filepath:
    x, y, z, time = [], [], [], []
    cnt+=1
    with open(ls, 'r') as f:
        lines = f.readlines()
        for line in lines:
            value = line.rstrip().split(',')
            x.append(float(value[0]))
            y.append(float(value[1]))
            z.append(float(value[2]))
            time.append(value[3])
    print(time[0])
    startTime = time[0].split(' ')[1].split('.')[0].split(':')
    startValue = int(startTime[1])*60 + int(startTime[-1])
    print(startValue)
    listTime = []
    for tm in time:
        va = tm.split(' ')[-1].split('.')[0].split(':')
        total = int(va[1])*60+int(va[-1])
        listTime.append(total - startValue)
    print(listTime)

    fig, ax = plt.subplots(figsize=(8,6)) 
    plt.plot(x, label='Gyro.x')
    plt.plot(y, label='Gyro.y')
    plt.plot(z, label='Gyro.z')
    plt.xticks(fontsize=5)
    plt.yticks(fontsize=15)
    plt.xlabel('time(s)', fontsize=15)
    plt.ylabel('Radians/s', fontsize=15)
    plt.legend(fontsize=18)


    # This changes the formatter.
    #plt.gca().xaxis.set_major_formatter(matplotlib.dates.DateFormatter("%Y-%m-%d %H:%M:%S.%f"))
    #plt.xticks(pandas.date_range(start='2022-05-23 16:24:54', end='2022-05-23 16:24:57'),rotation=45)#时间间隔
    if cnt==1:
        ticks = list(range(0, len(listTime),20))
    else:
        #ticks = list(range(0, len(time),200))
        ticks = list(range(0, len(listTime), int(len(listTime)/5)))
        print(ticks)
    #if ticks[-1]!=len(time)-1:
     #   ticks.append(len(time)-1)
    labels=[listTime[i] for i in ticks]
    #plt.gca().xaxis.set_major_formatter(matplotlib.dates.DateFormatter("%Y-%m-%d"))
    #plt.xticks(pandas.date_range(start=time[0], end=time[-1]))#时间间隔
    ax.set_xticks(ticks)
    ax.set_xticklabels(labels, rotation=30, horizontalalignment='right')
    plt.savefig(ls.split('.')[0]+'.pdf') # save the plotted figure in pdf file
    #plt.show()



